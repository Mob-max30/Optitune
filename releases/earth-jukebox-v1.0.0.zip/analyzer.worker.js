// extension/src/analysis/normalize.ts
function e(e, t = 0, n = 1) {
	return Number.isNaN(e) || e < t ? t : e > n ? n : e;
}
function t(e) {
	return Math.round(e * 1e3) / 1e3;
}
function n(n, r, i) {
	return i === r ? 0 : t(e((n - r) / (i - r), 0, 1));
}
// extension/src/analysis/luminance.ts
function r(e, t, n) {
	return (.299 * e + .587 * t + .114 * n) / 255;
}
function i(n, i = {}) {
	let a = n.length;
	if (a === 0) return 0;
	let o = i.ignoreDark ?? 0, s = 0, c = 0;
	for (let e = 0; e < a; e += 4) {
		let t = r(n[e], n[e + 1], n[e + 2]);
		t >= o && (s += t, c++);
	}
	return c === 0 ? 0 : t(e(s / c, 0, 1));
}
// extension/src/analysis/color.ts
function a(e, t, n) {
	let r = e / 255, i = t / 255, a = n / 255, o = Math.max(r, i, a), s = o - Math.min(r, i, a), c = 0;
	s !== 0 && (c = o === r ? (i - a) / s % 6 : o === i ? (a - r) / s + 2 : (r - i) / s + 4, c /= 6, c < 0 && (c += 1));
	let l = o === 0 ? 0 : s / o;
	return {
		h: c,
		s: l,
		v: o
	};
}
function o(n, r = {}) {
	let i = n.length;
	if (i === 0) return {
		dominantColor: {
			r: 0,
			g: 0,
			b: 0
		},
		hue: 0,
		saturation: 0
	};
	let o = r.ignoreDark ?? .05, s = r.minSaturation ?? .12, c = /* @__PURE__ */ new Uint32Array(12), l = /* @__PURE__ */ new Float64Array(12), u = /* @__PURE__ */ new Float64Array(12), d = /* @__PURE__ */ new Float64Array(12), f = /* @__PURE__ */ new Float64Array(12), p = 0, m = 0, h = 0, g = 0, _ = 0;
	for (let e = 0; e < i; e += 4) {
		let t = n[e], r = n[e + 1], i = n[e + 2], { h: v, s: y, v: b } = a(t, r, i);
		if (!(b < o) && (p += t, m += r, h += i, g += y, _++, y >= s)) {
			let e = Math.min(11, Math.floor(v * 12));
			c[e]++, l[e] += t, u[e] += r, d[e] += i, f[e] += y;
		}
	}
	if (_ === 0) return {
		dominantColor: {
			r: 0,
			g: 0,
			b: 0
		},
		hue: 0,
		saturation: 0
	};
	let v = -1, y = 0;
	for (let e = 0; e < 12; e++) c[e] > y && (y = c[e], v = e);
	if (v !== -1 && y > 0) {
		let n = c[v], r = t(e(l[v] / n / 255)), i = t(e(u[v] / n / 255)), a = t(e(d[v] / n / 255)), o = t(e(f[v] / n)), s = t((v + .5) / 12);
		return {
			dominantColor: {
				r,
				g: i,
				b: a
			},
			hue: s,
			saturation: o
		};
	}
	let b = t(e(p / _ / 255)), x = t(e(m / _ / 255)), S = t(e(h / _ / 255)), C = t(e(g / _));
	return {
		dominantColor: {
			r: b,
			g: x,
			b: S
		},
		hue: 0,
		saturation: C
	};
}
// extension/src/analysis/legend.ts
function s(e, t, n) {
	let r = e / 255, i = t / 255, a = n / 255;
	r = r > .04045 ? ((r + .055) / 1.055) ** 2.4 : r / 12.92, i = i > .04045 ? ((i + .055) / 1.055) ** 2.4 : i / 12.92, a = a > .04045 ? ((a + .055) / 1.055) ** 2.4 : a / 12.92;
	let o = (r * .4124 + i * .3576 + a * .1805) / .95047, s = (r * .2126 + i * .7152 + a * .0722) / 1, c = (r * .0193 + i * .1192 + a * .9505) / 1.08883, l = o > .008856 ? Math.cbrt(o) : 7.787 * o + 16 / 116, u = s > .008856 ? Math.cbrt(s) : 7.787 * s + 16 / 116, d = c > .008856 ? Math.cbrt(c) : 7.787 * c + 16 / 116;
	return {
		L: 116 * u - 16,
		a: 500 * (l - u),
		b: 200 * (u - d)
	};
}
function c(e, t) {
	let n = e.L - t.L, r = e.a - t.a, i = e.b - t.b;
	return Math.sqrt(n * n + r * r + i * i);
}
function l(e, t = 36) {
	return !e || !e.stops || e.stops.length === 0 ? null : {
		min: e.min ?? 0,
		max: e.max ?? 1,
		unit: e.unit ?? "",
		stops: e.stops.map((e) => ({
			color: e.color,
			lab: s(e.color[0], e.color[1], e.color[2]),
			value: e.value
		})),
		maxDeltaE: t
	};
}
function u(e, t, r, i) {
	let a = s(e, t, r), o = -1, l = Infinity, u = i.stops, d = u.length;
	for (let e = 0; e < d; e++) {
		let t = c(a, u[e].lab);
		t < l && (l = t, o = e);
	}
	if (l > i.maxDeltaE || o === -1) return null;
	let f = u[o], p = f.value, m = o > 0 ? u[o - 1] : null, h = o < d - 1 ? u[o + 1] : null, g = null, _ = Infinity;
	if (m && (_ = c(a, m.lab), g = m), h) {
		let e = c(a, h.lab);
		e < _ && (_ = e, g = h);
	}
	if (g && _ < i.maxDeltaE * 1.5) {
		let e = l + _;
		if (e > 0) {
			let t = 1 - l / e, n = 1 - _ / e, r = t + n;
			p = (f.value * t + g.value * n) / r;
		}
	}
	let v = n(p, i.min, i.max);
	return {
		rawValue: p,
		normalizedValue: v
	};
}
function d(n, r, i = 0) {
	if (!r) return null;
	let a = n.length, o = 0, s = 0;
	for (let e = 0; e < a; e += 4) {
		let t = u(n[e], n[e + 1], n[e + 2], r);
		t !== null && (o += t.normalizedValue, s++);
	}
	if (s === 0) return null;
	let c = a / 4;
	return c > 0 && i > 0 && s / c < i ? null : t(e(o / s, 0, 1));
}
// extension/src/analysis/regions.ts
function f(n, i, a) {
	let { rows: o, cols: s, width: c, height: l } = i, d = o * s, f = Array(d).fill(0), p = Array(d).fill(null), m = new Float64Array(d), h = new Uint32Array(d), g = new Float64Array(d), _ = new Uint32Array(d), v = i.ignoreDark ?? 0;
	for (let e = 0; e < l; e++) {
		let t = Math.min(o - 1, Math.floor(e / l * o)) * s;
		for (let i = 0; i < c; i++) {
			let o = t + Math.min(s - 1, Math.floor(i / c * s)), l = (e * c + i) * 4, d = n[l], f = n[l + 1], p = n[l + 2], y = r(d, f, p);
			if (y >= v && (m[o] += y, h[o]++), a) {
				let e = u(d, f, p, a);
				e !== null && (g[o] += e.normalizedValue, _[o]++);
			}
		}
	}
	for (let n = 0; n < d; n++) {
		let r = h[n];
		f[n] = r > 0 ? t(e(m[n] / r, 0, 1)) : 0;
		let i = _[n];
		p[n] = i > 0 ? t(e(g[n] / i, 0, 1)) : null;
	}
	return {
		rows: o,
		cols: s,
		brightness: f,
		dataValue: p
	};
}
function p(n, i, a, o = 32) {
	let s = Array(o).fill(0), c = Array(o).fill(0), l = new Float64Array(o), u = new Uint32Array(o), d = new Float64Array(o), f = new Uint32Array(o);
	for (let e = 0; e < a; e++) {
		let t = Math.min(o - 1, Math.floor(e / a * o));
		for (let a = 0; a < i; a++) {
			let s = Math.min(o - 1, Math.floor(a / i * o)), c = (e * i + a) * 4, p = r(n[c], n[c + 1], n[c + 2]);
			l[s] += p, u[s]++, d[t] += p, f[t]++;
		}
	}
	for (let n = 0; n < o; n++) s[n] = u[n] > 0 ? t(e(l[n] / u[n], 0, 1)) : 0, c[n] = f[n] > 0 ? t(e(d[n] / f[n], 0, 1)) : 0;
	return {
		cols: s,
		rows: c
	};
}
// extension/src/analysis/motion.ts
function m(n, i, a, o, s, c = {}) {
	if (!i || i.length !== n.length) return {
		motion: 0,
		sceneCut: !1,
		events: []
	};
	let l = n.length, u = a * o, d = 0;
	for (let e = 0; e < l; e += 4) {
		let t = Math.abs(n[e] - i[e]), r = Math.abs(n[e + 1] - i[e + 1]), a = Math.abs(n[e + 2] - i[e + 2]);
		d += (t + r + a) / 3;
	}
	let f = t(e(d / u / 255, 0, 1)), p = f > (c.sceneCutThreshold ?? .38), m = [];
	if (c.detectEvents && s) {
		let i = c.eventThreshold ?? .2, l = c.baselineAlpha ?? .05, u = /* @__PURE__ */ new Float32Array(64), d = /* @__PURE__ */ new Uint16Array(64);
		for (let e = 0; e < o; e++) {
			let t = Math.min(7, Math.floor(e / o * 8)) * 8;
			for (let i = 0; i < a; i++) {
				let o = t + Math.min(7, Math.floor(i / a * 8)), s = (e * a + i) * 4, c = r(n[s], n[s + 1], n[s + 2]);
				u[o] += c, d[o]++;
			}
		}
		for (let n = 0; n < 64; n++) {
			let r = d[n], a = r > 0 ? u[n] / r : 0, o = s[n], f = a - o;
			if (f > i) {
				let r = n % 8, i = Math.floor(n / 8), a = t((r + .5) / 8), o = t((i + .5) / 8), s = t(e(f, 0, 1));
				m.push({
					type: c.detectEvents === "flash" ? "flash" : "bright-spot",
					x: a,
					y: o,
					intensity: s
				});
			}
			s[n] = o + l * (a - o);
		}
	}
	return {
		motion: f,
		sceneCut: p,
		events: m
	};
}
// extension/src/worker/analyzer.worker.ts
var h = null, g = (/* @__PURE__ */ new Float32Array(64)).fill(.1), _ = null, v = null;
self.onmessage = (n) => {
	let r = n.data;
	if (r.type === "INIT") h = null, g.fill(.1), r.preset ? (v = r.preset.id, _ = l(r.preset.legend)) : (v = null, _ = null);
	else if (r.type === "ANALYZE_FRAME") {
		let { buffer: n, width: a, height: u, t: y, frameIndex: b, vizId: x, preset: S, seeked: C } = r, w = new Uint8ClampedArray(n);
		S && S.id !== v && (v = S.id, _ = l(S.legend), g.fill(.1), h = null);
		let T = S?.ignoreDark ?? .05, E = i(w, { ignoreDark: T }), D = o(w, { ignoreDark: T }), O = d(w, _), k = f(w, {
			rows: S?.grid?.[0] ?? 4,
			cols: S?.grid?.[1] ?? 8,
			width: a,
			height: u,
			ignoreDark: T
		}, _), A = {
			detectEvents: S?.events?.detect ?? null,
			eventThreshold: S?.events?.threshold ?? .2,
			baselineAlpha: S?.events?.baselineAlpha ?? .05
		}, j = m(w, C ? null : h, a, u, g, A), M;
		if (S?.layers && _ && _.stops.length >= S.layers.length) {
			M = {};
			let n = new Uint32Array(S.layers.length), r = _.stops, i = 0;
			for (let e = 0; e < w.length; e += 4) {
				let t = s(w[e], w[e + 1], w[e + 2]), a = -1, o = Infinity;
				for (let e = 0; e < r.length; e++) {
					let n = c(t, r[e].lab);
					n < o && (o = n, a = e);
				}
				o < _.maxDeltaE && a >= 0 && a < S.layers.length && (n[a]++, i++);
			}
			if (i > 0) for (let r = 0; r < S.layers.length; r++) {
				let a = S.layers[r];
				M[a] = t(e(n[r] / i, 0, 1));
			}
		}
		let N = p(w, a, u, 32);
		!h || h.length !== w.length ? h = new Uint8ClampedArray(w) : h.set(w);
		let P = {
			v: 1,
			t: t(y),
			frameIndex: b,
			vizId: x,
			metrics: {
				brightness: E,
				dominantColor: D.dominantColor,
				hue: D.hue,
				saturation: D.saturation,
				dataValue: O,
				motion: C ? 0 : j.motion,
				regions: k
			},
			flags: {
				seeked: !!C,
				scene_cut: j.sceneCut
			},
			events: j.events.length > 0 ? j.events : void 0,
			layers: M,
			profile: N
		};
		self.postMessage({
			type: "FRAME_ANALYZED",
			payload: P
		});
	}
};
