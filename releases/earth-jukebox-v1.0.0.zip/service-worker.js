chrome.runtime.onInstalled.addListener(() => {
	chrome.action.setBadgeBackgroundColor({ color: "#0B3D91" }), chrome.action.setBadgeText({ text: "" }), console.log("[EJB Background] Earth Jukebox installed successfully.");
}), chrome.commands.onCommand.addListener(async (t) => {
	if (t === "toggle-sonification") {
		let [t] = await chrome.tabs.query({
			active: !0,
			currentWindow: !0
		});
		t && t.id && chrome.tabs.sendMessage(t.id, { type: "TOGGLE_SONIFICATION" }, (n) => {
			chrome.runtime.lastError ? console.warn("[EJB Background] Content script not active on this tab:", chrome.runtime.lastError.message) : n && e(t.id, n.extensionEnabled ?? n.isActive);
		});
	}
}), chrome.runtime.onMessage.addListener((n, r, i) => n.type === "UPDATE_BADGE" && r.tab?.id ? (e(r.tab.id, n.isActive), i({ success: !0 }), !0) : n.type === "START_TAB_CAPTURE" ? (t(n.tabId || r.tab?.id).then((e) => i({
	success: !0,
	streamId: e
})).catch((e) => i({
	success: !1,
	error: String(e)
})), !0) : n.type === "CANVAS_TAINTED_DETECTED" && (console.warn("[EJB Background] Canvas tainted on tab:", r.tab?.id, n.url), i({ ack: !0 }), !0));
function e(e, t) {
	t ? (chrome.action.setBadgeText({
		tabId: e,
		text: "ON"
	}), chrome.action.setBadgeBackgroundColor({
		tabId: e,
		color: "#10B981"
	})) : chrome.action.setBadgeText({
		tabId: e,
		text: ""
	});
}
async function t(e) {
	if (!e) {
		let [t] = await chrome.tabs.query({
			active: !0,
			currentWindow: !0
		});
		if (!t || !t.id) throw Error("No active tab available for tabCapture");
		e = t.id;
	}
	let t = await chrome.tabCapture.getMediaStreamId({ targetTabId: e });
	return await n(), chrome.runtime.sendMessage({
		type: "INIT_OFFSCREEN_CAPTURE",
		streamId: t,
		targetTabId: e
	}), t;
}
async function n() {
	"offscreen" in chrome && chrome.offscreen && (await chrome.offscreen.hasDocument() || await chrome.offscreen.createDocument({
		url: "offscreen.html",
		reasons: [chrome.offscreen.Reason.USER_MEDIA],
		justification: "Capture video stream when direct canvas access is cross-origin tainted"
	}));
}
